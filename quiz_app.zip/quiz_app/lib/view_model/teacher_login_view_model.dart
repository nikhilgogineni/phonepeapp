import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TeacherLoginViewModel extends ChangeNotifier {
  FirebaseAuth auth = FirebaseAuth.instance;

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  loginTeacher() async {
    await auth.signInWithEmailAndPassword(
      email: emailController.text,
      password: passwordController.text,
    );
    notifyListeners();
  }
}
