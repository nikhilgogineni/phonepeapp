import 'package:flutter/material.dart';

class StudentLoginViewModel extends ChangeNotifier {}
