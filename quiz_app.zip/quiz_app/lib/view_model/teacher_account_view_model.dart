import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TeacherAccountViewModel extends ChangeNotifier {
  int selectedIndex = 1;

  FirebaseAuth auth = FirebaseAuth.instance;

  signout() async {
    await auth.signOut();
    notifyListeners();
  }
}
