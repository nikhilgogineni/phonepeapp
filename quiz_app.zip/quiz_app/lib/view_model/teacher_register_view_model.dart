import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';

class TeacherRegisterViewModel extends ChangeNotifier {
  FirebaseAuth auth = FirebaseAuth.instance;

  final teacherReference = FirebaseDatabase.instance.ref("teacher");

  TextEditingController usernameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  registerTeacher() async {
    await auth.createUserWithEmailAndPassword(
      email: emailController.text,
      password: passwordController.text,
    );
    String uid = auth.currentUser!.uid.toString();
    teacherReference.child(auth.currentUser!.uid).set({
      "username": usernameController.text,
      "email": emailController.text,
      "password": passwordController.text,
      "uid": uid,
    });
    notifyListeners();
  }
}
