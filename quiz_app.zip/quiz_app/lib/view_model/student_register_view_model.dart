import 'package:flutter/material.dart';

class StudentRegisterViewModel extends ChangeNotifier {}
