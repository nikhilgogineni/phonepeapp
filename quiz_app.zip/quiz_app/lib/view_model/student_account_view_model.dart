import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StudentAccountViewModel extends ChangeNotifier {
  int selectedIndex = 1;
  FirebaseAuth auth = FirebaseAuth.instance;

  signOut() async {
    await auth.signOut();
  }
}
