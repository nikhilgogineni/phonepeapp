import 'package:flutter/material.dart';

class StudentDashboardViewModel extends ChangeNotifier {
  int selectedIndex = 0;
}
