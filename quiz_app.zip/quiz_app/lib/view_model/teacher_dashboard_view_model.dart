import 'package:flutter/material.dart';

class TeacherDashboardViewModel extends ChangeNotifier {
  int selectedIndex = 0;
}
