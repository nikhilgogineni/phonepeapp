final strings = Strings();

class Strings {
  /// intro page
  final String welcome = "Welcome";
  final String student = "Student";
  final String teacher = "Teacher";

  /// login as teacher
  final String login = "Login";
  final String loginAsTeacher = "Login as Teacher";
  final String emailHead = "Email:";
  final String passwordHead = "Password:";
  final String usernameHead = "Username:";
  final String email = "Email";
  final String password = "Password";
  final String username = "Username";
  final String enterUsername = "Enter Username";
  final String enterEmail = "Enter Email";
  final String enterPassword = "Enter Password";
  final String noAccount = "Don't have an account? ";
  final String signUp = "Sign up";
  final String signIn = "Sign in";
  final String back = "Back";

  /// register as teacher
  final String register = "Register";
  final String registerAsTeacher = "Register as Teacher";
  final String alreadyHaveAccount = "Already have an account? ";

  /// profile screen
  final String profile = "Profile";
  final String signOut = "Sign out";

  /// bootom navigatio
  final String home = "Home";
  final String account = "Account";

  /// student login view
  final String studentLogin = "Login as Student";

  /// student register view
  final String studentRegister = "Register as Student";

  /// teacher - student dashboard
  final String dashboard = "Dashboard";
  final String class1 = "Class 1";
  final String class2 = "Class 2";
  final String class3 = "Class 3";
  final String class4 = "Class 4";
  final String class5 = "Class 5";
  final String class6 = "Class 6";
  final String class7 = "Class 7";
  final String class8 = "Class 8";
  final String class9 = "Class 9";
  final String class10 = "Class 10";

  /// subject categories
  final String math = "Math";
  final String science = "Science";
  final String chemistry = "Chemistry";
  final String biology = "Biology";
}
