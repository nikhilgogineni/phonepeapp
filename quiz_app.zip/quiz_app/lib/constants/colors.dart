import 'package:flutter/material.dart';

final customColors = CustomColors();

class CustomColors {
  final Color white = Colors.white;
  final Color deepPurple = Colors.deepPurple;
  final Color red = Colors.red;
}
