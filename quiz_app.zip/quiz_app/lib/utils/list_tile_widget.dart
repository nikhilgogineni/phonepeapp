import 'package:flutter/material.dart';
import 'package:quiz_app/utils/subject_widget.dart';
import 'package:quiz_app/view/categories/biology_view.dart';
import 'package:quiz_app/view/categories/chemistry_view.dart';
import 'package:quiz_app/view/categories/math._view.dart';
import 'package:quiz_app/view/categories/science_view.dart';

// ignore: must_be_immutable
class ListTileWidget extends StatefulWidget {
  String className;
  ListTileWidget({Key? key, required this.className}) : super(key: key);

  @override
  State<ListTileWidget> createState() => _ListTileWidgetState();
}

class _ListTileWidgetState extends State<ListTileWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Card(
        child: ListTile(
          onTap: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => SubjectWidget(
                className: widget.className,
                onTapMath: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const MathView(),
                    ),
                  );
                },
                onTapScience: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const ScienceView(),
                    ),
                  );
                },
                onTapChemistry: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const ChemistryView(),
                    ),
                  );
                },
                onTapBiology: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const BiologyView(),
                    ),
                  );
                },
              ),
            ));
          },
          title: Text(widget.className),
        ),
      ),
    );
  }
}
