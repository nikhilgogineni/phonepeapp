import 'package:flutter/material.dart';
import 'package:quiz_app/constants/strings.dart';

// ignore: must_be_immutable
class SubjectWidget extends StatefulWidget {
  String className;
  VoidCallback? onTapMath;
  VoidCallback? onTapScience;
  VoidCallback? onTapChemistry;
  VoidCallback? onTapBiology;
  SubjectWidget(
      {Key? key,
      required this.className,
      this.onTapMath,
      this.onTapScience,
      this.onTapChemistry,
      this.onTapBiology})
      : super(key: key);

  @override
  State<SubjectWidget> createState() => _SubjectWidgetState();
}

class _SubjectWidgetState extends State<SubjectWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.className),
        centerTitle: true,
      ),
      body: GridView(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, childAspectRatio: 0.75),
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: widget.onTapMath,
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(20)),
                child: Center(
                  child: Text(strings.math),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: widget.onTapScience,
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(20)),
                child: Center(
                  child: Text(strings.science),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: widget.onTapChemistry,
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(20)),
                child: Center(
                  child: Text(strings.chemistry),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: widget.onTapBiology,
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(),
                    borderRadius: BorderRadius.circular(20)),
                child: Center(
                  child: Text(strings.biology),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
