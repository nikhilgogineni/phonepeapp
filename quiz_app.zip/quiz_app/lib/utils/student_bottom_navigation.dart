import 'package:flutter/material.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/constants/strings.dart';
import 'package:quiz_app/view/teacher_account_view.dart';
import 'package:quiz_app/view/teacher_dashboard_view.dart';

// ignore: must_be_immutable
class StudentBottomNavigation extends StatefulWidget {
  int selectedIndex;
  StudentBottomNavigation({Key? key, required this.selectedIndex})
      : super(key: key);

  @override
  State<StudentBottomNavigation> createState() =>
      _StudentBottomNavigationState();
}

class _StudentBottomNavigationState extends State<StudentBottomNavigation> {
  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      onTap: (index) {
        widget.selectedIndex = index;
        if (index == 0) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const TeacherDashboardView(),
              ),
              (route) => false);
        } else if (index == 1) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => const TeacherAccountView(),
              ),
              (route) => false);
        }
      },
      type: BottomNavigationBarType.fixed,
      unselectedItemColor: Colors.black,
      selectedItemColor: customColors.deepPurple,
      currentIndex: widget.selectedIndex,
      items: [
        BottomNavigationBarItem(
          icon: const Icon(Icons.home),
          label: strings.home,
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.person),
          label: strings.account,
        ),
      ],
    );
  }
}
