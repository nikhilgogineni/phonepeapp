import 'package:flutter/material.dart';
import 'package:quiz_app/utils/student_bottom_navigation.dart';
import 'package:quiz_app/view_model/student_dashboard_view_model.dart';
import 'package:stacked/stacked.dart';
import 'package:quiz_app/utils/list_tile_widget.dart';
import 'package:quiz_app/constants/strings.dart';

class StudentDashboardView extends StatefulWidget {
  const StudentDashboardView({Key? key}) : super(key: key);

  @override
  State<StudentDashboardView> createState() => _StudentDashboardViewState();
}

class _StudentDashboardViewState extends State<StudentDashboardView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<StudentDashboardViewModel>.reactive(
      viewModelBuilder: () => StudentDashboardViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: Text(strings.dashboard),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              ListTileWidget(
                className: strings.class1,
              ),
              ListTileWidget(
                className: strings.class2,
              ),
              ListTileWidget(
                className: strings.class3,
              ),
              ListTileWidget(
                className: strings.class4,
              ),
              ListTileWidget(
                className: strings.class5,
              ),
              ListTileWidget(
                className: strings.class6,
              ),
              ListTileWidget(
                className: strings.class7,
              ),
              ListTileWidget(
                className: strings.class8,
              ),
              ListTileWidget(
                className: strings.class9,
              ),
              ListTileWidget(
                className: strings.class10,
              ),
            ],
          ),
        ),
        bottomNavigationBar:
            StudentBottomNavigation(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
