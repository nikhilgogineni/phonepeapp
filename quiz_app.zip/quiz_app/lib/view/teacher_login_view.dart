import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/view/intro_page.dart';
import 'package:quiz_app/view/teacher_dashboard_view.dart';
import 'package:quiz_app/view_model/teacher_login_view_model.dart';
import 'package:quiz_app/view/teacher_register_view.dart';
import 'package:quiz_app/utils/custom_button.dart';
import 'package:stacked/stacked.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/constants/strings.dart';

class TeacherLoginView extends StatefulWidget {
  const TeacherLoginView({Key? key}) : super(key: key);

  @override
  State<TeacherLoginView> createState() => _TeacherLoginViewState();
}

class _TeacherLoginViewState extends State<TeacherLoginView> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<TeacherLoginViewModel>.reactive(
      viewModelBuilder: () => TeacherLoginViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        backgroundColor: customColors.white,
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                const SizedBox(
                  height: 60,
                ),
                Center(
                  child: Text(
                    strings.loginAsTeacher,
                    style: TextStyle(
                      color: customColors.deepPurple,
                      fontSize: 22,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    strings.emailHead,
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: strings.email,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      errorStyle:
                          TextStyle(color: customColors.red, fontSize: 18),
                      fillColor: customColors.white,
                      filled: true,
                    ),
                    validator: (email) {
                      if (email == null || email.isEmpty) {
                        return strings.enterEmail;
                      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          .hasMatch(email)) {
                        return "Invalid email";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    strings.passwordHead,
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: strings.password,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      errorStyle:
                          TextStyle(color: customColors.red, fontSize: 18),
                      fillColor: customColors.white,
                      filled: true,
                    ),
                    validator: (password) {
                      if (password == null || password.isEmpty) {
                        return strings.enterPassword;
                      } else if (!RegExp(
                              r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                          .hasMatch(password)) {
                        return "Invalid password";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: InkWell(
                    onTap: () async {
                      if (formKey.currentState!.validate()) {
                        try {
                          // await viewModel.loginTeacher();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("Logged in successfully"),
                              showCloseIcon: true,
                            ),
                          );
                          Navigator.of(context).pushAndRemoveUntil(
                              MaterialPageRoute(
                                builder: (context) =>
                                    const TeacherDashboardView(),
                              ),
                              (route) => false);
                        } on FirebaseAuthException catch (e) {
                          if (e.code == "user-not-found") {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("user not found"),
                                showCloseIcon: true,
                              ),
                            );
                          } else if (e.code == "wrong-password") {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("wrong password"),
                                showCloseIcon: true,
                              ),
                            );
                          }
                        }
                      }
                    },
                    child: CustomButton(
                      textName: strings.login,
                      color1: customColors.deepPurple,
                      color2: customColors.white,
                    ),
                  ),
                ),
                // const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      strings.noAccount,
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              maintainState: true,
                              builder: (context) => const TeacherRegisterView(),
                            ),
                            (route) => false);
                      },
                      child: Text(
                        strings.signUp,
                        style: TextStyle(
                          color: customColors.deepPurple,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              maintainState: true,
                              builder: (context) => const IntroPage(),
                            ),
                            (route) => false);
                      },
                      child: Text(
                        strings.back,
                        style: TextStyle(
                          color: customColors.deepPurple,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
