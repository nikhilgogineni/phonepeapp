import 'package:flutter/material.dart';

class MathView extends StatefulWidget {
  const MathView({Key? key}) : super(key: key);

  @override
  State<MathView> createState() => _MathViewState();
}

class _MathViewState extends State<MathView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Math"),
        centerTitle: true,
      ),
    );
  }
}
