import 'package:flutter/material.dart';

class BiologyView extends StatefulWidget {
  const BiologyView({Key? key}) : super(key: key);

  @override
  State<BiologyView> createState() => _BiologyViewState();
}

class _BiologyViewState extends State<BiologyView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Biology"),
        centerTitle: true,
      ),
    );
  }
}
