import 'package:flutter/material.dart';

class ChemistryView extends StatefulWidget {
  const ChemistryView({Key? key}) : super(key: key);

  @override
  State<ChemistryView> createState() => _ChemistryViewState();
}

class _ChemistryViewState extends State<ChemistryView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chemistry"),
        centerTitle: true,
      ),
    );
  }
}
