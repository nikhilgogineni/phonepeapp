import 'package:flutter/material.dart';

class ScienceView extends StatefulWidget {
  const ScienceView({Key? key}) : super(key: key);

  @override
  State<ScienceView> createState() => _ScienceViewState();
}

class _ScienceViewState extends State<ScienceView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Science"),
        centerTitle: true,
      ),
    );
  }
}
