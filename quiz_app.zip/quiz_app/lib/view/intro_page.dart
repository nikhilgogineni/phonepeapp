import 'package:flutter/material.dart';
import 'package:quiz_app/view//student_login_view.dart';
import 'package:quiz_app/view//teacher_login_view.dart';
import 'package:quiz_app/utils/custom_button.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/constants/strings.dart';

class IntroPage extends StatefulWidget {
  const IntroPage({Key? key}) : super(key: key);

  @override
  State<IntroPage> createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: customColors.deepPurple,
      body: Column(
        children: [
          const SizedBox(height: 120),
          Center(
            child: Text(strings.welcome,
                style: TextStyle(
                  color: customColors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                )),
          ),
          const SizedBox(height: 60),
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: () {
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (context) => const StudentLoginView(),
                    ),
                    (route) => false);
              },
              child: CustomButton(
                textName: strings.student,
                color1: customColors.white,
                color2: customColors.deepPurple,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: InkWell(
              onTap: () {
                Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      maintainState: true,
                      builder: (context) => const TeacherLoginView(),
                    ),
                    (route) => false);
              },
              child: CustomButton(
                textName: strings.teacher,
                color1: customColors.white,
                color2: customColors.deepPurple,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
