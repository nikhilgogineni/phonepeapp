import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/view/teacher_login_view.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/view_model/teacher_register_view_model.dart';
import 'package:quiz_app/utils/custom_button.dart';
import 'package:stacked/stacked.dart';
import 'package:quiz_app/constants/strings.dart';

class TeacherRegisterView extends StatefulWidget {
  const TeacherRegisterView({Key? key}) : super(key: key);

  @override
  State<TeacherRegisterView> createState() => _TeacherRegisterViewState();
}

class _TeacherRegisterViewState extends State<TeacherRegisterView> {
  @override
  Widget build(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    return ViewModelBuilder<TeacherRegisterViewModel>.reactive(
      viewModelBuilder: () => TeacherRegisterViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        body: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 60,
                ),
                Center(
                  child: Text(
                    strings.registerAsTeacher,
                    style: TextStyle(
                      color: customColors.deepPurple,
                      fontSize: 22,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    strings.usernameHead,
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: strings.username,
                      fillColor: customColors.white,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      errorStyle:
                          TextStyle(color: customColors.red, fontSize: 18),
                    ),
                    validator: (name) {
                      if (name == null || name.isEmpty) {
                        return strings.enterUsername;
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    strings.emailHead,
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: strings.email,
                      fillColor: customColors.white,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      errorStyle:
                          TextStyle(color: customColors.red, fontSize: 18),
                    ),
                    validator: (email) {
                      if (email == null || email.isEmpty) {
                        return strings.enterEmail;
                      } else if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          .hasMatch(email)) {
                        return "Invalid password";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Text(
                    strings.password,
                    style: const TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: strings.password,
                      fillColor: customColors.white,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      errorStyle:
                          TextStyle(color: customColors.red, fontSize: 18),
                    ),
                    validator: (password) {
                      if (password == null || password.isEmpty) {
                        return strings.enterPassword;
                      } else if (!RegExp(
                              r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$')
                          .hasMatch(password)) {
                        return "Invalid password";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: InkWell(
                    onTap: () async {
                      if (formKey.currentState!.validate()) {
                        try {
                          // await viewModel.registerTeacher();
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("registered successfully"),
                              showCloseIcon: true,
                            ),
                          );
                        } on FirebaseAuthException catch (e) {
                          if (e.code == "email-already-in-use") {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("email already in use"),
                                showCloseIcon: true,
                              ),
                            );
                          }
                        }
                      }
                    },
                    child: CustomButton(
                      textName: strings.register,
                      color1: customColors.deepPurple,
                      color2: customColors.white,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      strings.alreadyHaveAccount,
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pushAndRemoveUntil(
                            MaterialPageRoute(
                              maintainState: true,
                              builder: (context) => const TeacherLoginView(),
                            ),
                            (route) => false);
                      },
                      child: Text(
                        strings.signIn,
                        style: TextStyle(
                          color: customColors.deepPurple,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
