import 'package:flutter/material.dart';
import 'package:quiz_app/view_model/student_account_view_model.dart';
import 'package:quiz_app/utils/student_bottom_navigation.dart';
import 'package:stacked/stacked.dart';
import 'package:quiz_app/constants/strings.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/utils/custom_button.dart';

class StudentAccountView extends StatefulWidget {
  const StudentAccountView({Key? key}) : super(key: key);

  @override
  State<StudentAccountView> createState() => _StudentAccountViewState();
}

class _StudentAccountViewState extends State<StudentAccountView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<StudentAccountViewModel>.reactive(
      viewModelBuilder: () => StudentAccountViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: Text(strings.profile),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.person,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.usernameHead),
                subtitle: Text(strings.username),
                trailing: IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.edit,
                    color: customColors.deepPurple,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.mail,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.emailHead),
                subtitle: Text(strings.email),
                trailing: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.edit,
                      color: customColors.deepPurple,
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.password,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.passwordHead),
                subtitle: Text(strings.password),
                trailing: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.edit,
                      color: customColors.deepPurple,
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: InkWell(
                onTap: () async {
                  await viewModel.signOut();
                },
                child: CustomButton(
                  textName: strings.signOut,
                  color1: customColors.deepPurple,
                  color2: customColors.white,
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar:
            StudentBottomNavigation(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
