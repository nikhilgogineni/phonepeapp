import 'package:flutter/material.dart';
import 'package:quiz_app/constants/colors.dart';
import 'package:quiz_app/view/intro_page.dart';
import 'package:quiz_app/view_model/teacher_account_view_model.dart';
import 'package:quiz_app/utils/teacher_bottom_navigation.dart';
import 'package:quiz_app/utils/custom_button.dart';
import 'package:stacked/stacked.dart';
import 'package:quiz_app/constants/strings.dart';

class TeacherAccountView extends StatefulWidget {
  const TeacherAccountView({Key? key}) : super(key: key);

  @override
  State<TeacherAccountView> createState() => _TeacherAccountViewState();
}

class _TeacherAccountViewState extends State<TeacherAccountView> {
  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<TeacherAccountViewModel>.reactive(
      viewModelBuilder: () => TeacherAccountViewModel(),
      builder: (context, viewModel, child) => Scaffold(
        appBar: AppBar(
          title: Text(strings.profile),
          centerTitle: true,
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.person,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.usernameHead),
                subtitle: Text(strings.username),
                trailing: IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.edit,
                    color: customColors.deepPurple,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.mail,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.emailHead),
                subtitle: Text(strings.email),
                trailing: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.edit,
                      color: customColors.deepPurple,
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 5,
                bottom: 5,
              ),
              child: ListTile(
                leading: Icon(
                  Icons.password,
                  color: customColors.deepPurple,
                  size: 30,
                ),
                title: Text(strings.passwordHead),
                subtitle: Text(strings.password),
                trailing: IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.edit,
                      color: customColors.deepPurple,
                    )),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: InkWell(
                onTap: () async {
                  // await viewModel.signout();
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                        builder: (context) => const IntroPage(),
                      ),
                      (route) => false);
                },
                child: CustomButton(
                  textName: strings.signOut,
                  color1: customColors.deepPurple,
                  color2: customColors.white,
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar:
            TeacherBottomNavigation(selectedIndex: viewModel.selectedIndex),
      ),
    );
  }
}
